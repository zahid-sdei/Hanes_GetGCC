﻿//#define USENETWORK

using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using iCiX.DTS.Data;
using iCiX.DTS.Data.DocumentDataSetTableAdapters;
using iCiX.DTS.Data.DocumentTypesDataSetTableAdapters;
using iCiX.DTS.Data.QuarantineFileDataSetTableAdapters;
using iCiX.DTS.Data.MailBoxMessagesDataSetTableAdapters;

using iCiX.FrameWork.Core;
using iCiX.FrameWork.Data;
using iCiX.FrameWork.Email;

using iCiX.FrameWork.Email.EmailDataSetTableAdapters;

namespace iCiX.Execution.Packages
{
    /// <summary>
    /// This package processes the image copy items
    /// 
    /// Example is when products are published files need to be moved on the physical location
    /// </summary>
    public class ProcessPDFOutPackage : BasePackage
    {
        private const string ConstThisClassName = "ProcessPDFOutPackage";
        /// <summary>
        /// </summary>

        private enum DocumentSourceDirectory
        {
            ResultsDirectory = 1,
            ConvertedDirectory = 2,
            ErrorDirectory = 3
        }

        public ProcessPDFOutPackage(PackageConfiguration packageConfiguration) : base(packageConfiguration, ConstThisClassName) { }

        public override int Execute()
        {
            int executionResult = 0;
            _logger.WriteLog("Started");

            executionResult = this.Run();

            _logger.WriteLog("Done");
            return executionResult;
        }

        private int Run()
        {
            int executionResult = 0;
            SqlConnection connection = null;

            try
            {
                connection = new SqlConnection(_sqlConnectionString);
                connection.Open();

                //Get the list of DocumentPathes by docTypeId to process
                DocTypesTableAdapter docTypesTableAdapter =
                    DataSqlAdaptersFactory.GetAdapter<DocTypesTableAdapter>(connection);
                DocumentTypesDataSet.DocTypesDataTable docTypesDataTable = docTypesTableAdapter.GetDataToProcessPdfOut();

                foreach (DocumentTypesDataSet.DocTypesRow docTypesRow in docTypesDataTable)
                {
                    ProcessPdfOutStart(docTypesRow, connection);
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex, "Error: Run");
                executionResult = 0;
            }
            finally
            {
                if (connection != null)
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection = null;
                }
            }
            return executionResult;

        }

        private void ProcessPdfOutStart(DocumentTypesDataSet.DocTypesRow docTypesRow, SqlConnection connection)
        {
            try
            {
                /* this routine clears the contents of the 'Results' folder - which are the
		        files which have been successfully processed. We a) insert blobs of them
		        into the relevant db record, then move the PDF file to the relevant archive dir
		        grab the folders we are going to examine and use for this docTypeId */
                ProcessFilesFromFolder(DocumentSourceDirectory.ResultsDirectory, docTypesRow, connection);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex.Message, "Error: ProcessFilesFromFolder ResultsDirectory");
            }
            try
            {
                /* this routine clears the contents of the 'Converted' folder - which are the
	             originals of the files which have been successfull processed. We move them
	             all to the relevant archive folder for the document type.
	             If DLog=True then objLogFile.WriteLine Now() & ": Start ClearConverted for docTypeId '" & docTypeId & "'"
	             grab the folders we are going to examine and use for this docTypeId */
                ProcessFilesFromFolder(DocumentSourceDirectory.ConvertedDirectory, docTypesRow, connection);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex.Message, "Error: ProcessFilesFromFolder ConvertedDirectory");
            }
            try
            {
                /* ' This routine clears the contents of the 'Errors' folder, which are the files
	             which failed to process into PDFs. We move them to the designated quarantine folder
	             and change their fileStatus = 4 = quarantine. And insert a record into tblQFiles.
	             They then should show in the Manual
	             Import Section of the System Admin, and so can be manually downloaded, checked, and 
	             re-uploaded once successfully converted. And send an email to alert.
		         If DLog=True then objLogFile.WriteLine Now() & ": Start ClearErrors for docTypeId '" & docTypeId & "'"
		         grab the folders we are going to examine and use for this docTypeId */
                ProcessFilesFromFolder(DocumentSourceDirectory.ErrorDirectory, docTypesRow, connection);
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex.Message, "Error: ProcessFilesFromFolder ErrorDirectory");
            }
        }
        private void ProcessFilesFromFolder(DocumentSourceDirectory documentSourceDirectory, DocumentTypesDataSet.DocTypesRow docTypesRow,
                                    SqlConnection connection)
        {
            try
            {
                FileHandler fh = new FileHandler();
                FileInfo[] fileInfos = null;
                //string fileNamePattern;
                //set document's source and destination directory

                //Get List of files from soure Directory and process the one by one 
                //fileNamePattern = GetFileNamePatternByDocTypeId(docTypesRow.docTypeId);

#if LOCALPATHFORSAN
                DirectoryInfo dirInfo;
                if (documentSourceDirectory == DocumentSourceDirectory.ResultsDirectory)
                    dirInfo = new DirectoryInfo(@"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\Results\");
                else if (documentSourceDirectory == DocumentSourceDirectory.ConvertedDirectory)
                    dirInfo = new DirectoryInfo(@"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\Converted\");
                else
                    dirInfo = new DirectoryInfo(@"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\Error\");
                //fileInfos = dirInfo.GetFiles(fileNamePattern);
                fileInfos = dirInfo.GetFiles();
#else
                if (documentSourceDirectory == DocumentSourceDirectory.ResultsDirectory)
                {
                    _logger.WriteLog(new StringBuilder("Callning fh.GetFiles \"").Append(docTypesRow.docPathResults).Append("\"").ToString());
#if USENETWORK
//                    fileInfos = fh.GetFiles(docTypesRow.docPathResults, fileNamePattern, _packageConfiguration.SANNetworkUserIdentity);
                    fileInfos = fh.GetFiles(docTypesRow.docPathResults, _packageConfiguration.SANNetworkUserIdentity);
#else
//                    fileInfos = fh.GetFiles(docTypesRow.docPathResults, fileNamePattern);
                    fileInfos = fh.GetFiles(docTypesRow.docPathResults);
#endif
                }
                else if (documentSourceDirectory == DocumentSourceDirectory.ConvertedDirectory)
                {
                    _logger.WriteLog(new StringBuilder("Callning fh.GetFiles \"").Append(docTypesRow.docPathConverted).Append("\"").ToString());
#if USENETWORK
//                    fileInfos = fh.GetFiles(docTypesRow.docPathConverted, fileNamePattern, _packageConfiguration.SANNetworkUserIdentity);
                    fileInfos = fh.GetFiles(docTypesRow.docPathConverted, _packageConfiguration.SANNetworkUserIdentity);
#else
//                    fileInfos = fh.GetFiles(docTypesRow.docPathConverted, fileNamePattern);
                    fileInfos = fh.GetFiles(docTypesRow.docPathConverted);
#endif
                }
                else
                {
                    _logger.WriteLog(new StringBuilder("Callning fh.GetFiles \"").Append(docTypesRow.docPathErrors).Append("\"").ToString());
#if USENETWORK
//                    fileInfos = fh.GetFiles(docTypesRow.docPathErrors, fileNamePattern, _packageConfiguration.SANNetworkUserIdentity);
                    fileInfos = fh.GetFiles(docTypesRow.docPathErrors, _packageConfiguration.SANNetworkUserIdentity);
#else
//                    fileInfos = fh.GetFiles(docTypesRow.docPathErrors, fileNamePattern);
                    fileInfos = fh.GetFiles(docTypesRow.docPathErrors);
#endif
                }

                _logger.WriteLog((fileInfos == null).ToString());

#endif

                foreach (FileInfo fileInfo in fileInfos)
                {
                    try
                    {
                        ProcessOneFileFromFolder(documentSourceDirectory, fileInfo, docTypesRow, connection);
                    }
                    catch (Exception exc)
                    {
                        _logger.WriteLog(exc.Message + "\n" + exc.StackTrace, "ProcessOneFileFromFolder");//log and process next file
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(new StringBuilder(ex.Message).Append(Environment.NewLine).Append(ex.StackTrace).ToString()); 
                //error on loading DirectoryInfo
            }
        }

        //private string GetFileNamePatternByDocTypeId(int docTypeId)
        //{
        //    string fileNamePattern = "";

        //    switch (docTypeId)
        //    {
        //        case 1: //Certification
        //            fileNamePattern = "cert*";
        //            break;
        //        case 2://Product Document
        //            fileNamePattern = "docdoc*";
        //            break;
        //        case 3: //Approved Supplier Compliance Document
        //        case 11:// Document Log
        //        case 13:// Emergency Policies
        //            fileNamePattern = "doc[0-9]+[.]*";
        //            break;
        //        case 5:// Incidents
        //            fileNamePattern = "car*";
        //            break;
        //        case 6:// Organisation Profiles
        //            fileNamePattern = "profile*";
        //            break;
        //        case 14:// SOCS
        //            fileNamePattern = "soc*";
        //            break;
        //        case 15:// Recall
        //            fileNamePattern = "rcl*";
        //            break;
        //        case 19:// Freeview
        //            fileNamePattern = "freeview*";
        //            break;
        //        default:
        //            fileNamePattern = "*";
        //            break;
        //    }
        //    return fileNamePattern;
        //}

        private void ProcessOneFileFromFolder(DocumentSourceDirectory documentSourceDirectory, FileInfo fileInfo,
                                              DocumentTypesDataSet.DocTypesRow docTypesRow, SqlConnection connection)
        {
            string fileName = fileInfo.Name.ToLower().Replace("$asq", "");
            string fileNameLookUp = fileInfo.Name.Substring(0, fileInfo.Name.Length - fileInfo.Extension.Length);

            _logger.WriteLog(new StringBuilder("processing documentSourceDirectory = ").Append(documentSourceDirectory.ToString()).Append(" fileName ").Append(fileName).ToString());

            FileHandler fileHandler = new FileHandler();

            FindDocumentRecordByFileNameTableAdapter docFindTableAdapter =
                DataSqlAdaptersFactory.GetAdapter<FindDocumentRecordByFileNameTableAdapter>(connection);

            //this call will return a row including the proper docTypeId and path information
            DocumentDataSet.FindDocumentRecordByFileNameDataTable docFindDataTable =
                docFindTableAdapter.GetData(fileNameLookUp);

            // Nothing found, nothing to do.
            if (docFindDataTable.Rows.Count == 0)
            {
                _logger.WriteLog(new StringBuilder("Not found FindDocumentRecordByFileName(").Append(docTypesRow.docTypeId).Append(", ").Append(fileNameLookUp.Length).Append(", ").Append(fileNameLookUp).Append(")").ToString());
                ProcessNonFoundFile(fileInfo, docTypesRow, connection);
                return;
            }

            string destinationDirectory;
            int fileSize = 0;
            foreach (DocumentDataSet.FindDocumentRecordByFileNameRow documentsRow in docFindDataTable)
            {
                if  ((documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Certificate
                    || documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Recall
                    || documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Product
					|| documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Incident
                    || documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.SOCS
                    || documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.ApprovedSupplierComplianceDocument)
                    && documentSourceDirectory == DocumentSourceDirectory.ResultsDirectory
                    ) //Certificates and Recall
                {
                    destinationDirectory = documentsRow.docPath; // Certificates/Recall only for now
#if LOCALPATHFORSAN
                    destinationDirectory = @"C:\iCiXLocalMachineSan\docs\";
                    
#endif

                    //need to get the file size before moving the file
                    fileSize = (int)fileInfo.Length;
                    string destinationPath = destinationDirectory +
                        GenerateSubfolders(
                            documentsRow.orgId,
                            documentsRow.primaryDocId,
                            documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Certificate ?
								BinaryDocumentType.Certificate :
									(
										documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Recall ?
											BinaryDocumentType.Recall :
												(
													documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Product ?
														BinaryDocumentType.Product :
															(
																documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.ApprovedSupplierComplianceDocument ?
																	BinaryDocumentType.ApprovedSupplierComplianceDocument : 
                                                                    (
                                                                        documentsRow.docTypeId == (int)DocumentTypesDataSet.DocTypesRow.DocumentType.Incident ? BinaryDocumentType.Incident 
                                                                        : BinaryDocumentType.SOCS
                                                                    )
															)
												)
									)
							);
                    string destinationFile = GenerateFileName(documentsRow.orgId, documentsRow.primaryDocId, documentsRow.secondDocId);

#if USENETWORK
                    int result = fileHandler.MoveFileToNetwork(fileInfo.FullName, destinationPath, destinationFile,
                                                  _packageConfiguration.SANNetworkUserIdentity);
#else
                    int result = fileHandler.MoveFile(fileInfo.FullName, destinationPath, destinationFile);
#endif

                    _logger.WriteLog(new StringBuilder("moving result = ").Append(result).Append(" file ").Append(fileInfo.FullName).Append(" to ").Append(destinationPath).Append(destinationFile).ToString());

#if USENETWORK
                    bool fileExist = fileHandler.FileExistsOnNetwork(destinationPath + destinationFile,
                        _packageConfiguration.SANNetworkUserIdentity);
#else
                    bool fileExist = fileHandler.FileExists(destinationPath + destinationFile);
#endif

                    if (!fileExist)
                    {
                        _logger.WriteLog("FileNotFound");
                        Environment.Exit(6);
                    }


                    //Set fileStatus = (3) Available
                    //for certificates we also update the file size
                    docFindTableAdapter.UpdateDocumentFileStatusAndSize(documentsRow.primaryDocId, documentsRow.tableSource,
                                                                   (int)DocumentFileStatus.Available, fileInfo.Name.ToLower(),
                                                                   fileSize);
                }
                else //other Types of documents
                {
                    //set destinationDirectory for Document Files, types of which are other than Certificates 
                    destinationDirectory = documentsRow.docPathArchive;
#if LOCALPATHFORSAN
                    destinationDirectory = @"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\Archive\";
#endif
                    if (documentSourceDirectory == DocumentSourceDirectory.ResultsDirectory)
                    {
                        _logger.WriteLog(new StringBuilder("DocumentSourceDirectory.ResultsDirectory saving to database ").Append(fileInfo.Name).ToString());
                        SaveNewBinaryFileToDataBase(fileHandler, docFindTableAdapter, documentsRow, fileInfo, connection);
                    }
                    else if (documentSourceDirectory == DocumentSourceDirectory.ErrorDirectory)
                    {
                        _logger.WriteLog(new StringBuilder("DocumentSourceDirectory.ErrorDirectory saving to AddFileToQuarantine ").Append(fileInfo.Name).ToString());
                        //Set fileStatus = (4) Quarantined
                        docFindTableAdapter.UpdateDocumentFileStatus(documentsRow.primaryDocId, documentsRow.tableSource,
                                                                 (int)DocumentFileStatus.Quarantined, fileInfo.Name.ToLower());

                        AddFileToQuarantine(documentsRow, fileInfo, connection);
                        //reset destinationDirectory for bad Document Files 
                        destinationDirectory = documentsRow.qPath;
#if LOCALPATHFORSAN
                        destinationDirectory = @"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\qPath\";
#endif

                        _logger.WriteLog(new StringBuilder("ProcessPdfOutPackage found NOT converted file: ").Append(fileInfo.FullName).Append(". File has been moved to ").Append(destinationDirectory).ToString());
                        SendError(BuildEmailBody(new StringBuilder("ProcessPdfOutPackage found NOT converted file: ").Append(fileInfo.FullName).Append(". \n     File has been moved to ").Append(destinationDirectory).ToString()), connection);

                    }
                    _logger.WriteLog(new StringBuilder("MoveFileToNetwork ").Append(fileInfo.FullName).Append(" destinationDirectory = ").Append(destinationDirectory).Append(fileName).ToString());

#if USENETWORK
                    fileHandler.MoveFileToNetwork(fileInfo.FullName, destinationDirectory, fileName,
                                                  _packageConfiguration.SANNetworkUserIdentity);
#else
                    fileHandler.MoveFile(fileInfo.FullName, destinationDirectory, fileName);
#endif

#if USENETWORK
                    bool fileExist = fileHandler.FileExistsOnNetwork(destinationDirectory + fileName,
                        _packageConfiguration.SANNetworkUserIdentity);
#else
                    bool fileExist = fileHandler.FileExists(destinationDirectory + fileName);
#endif

                    if (!fileExist)
                    {
                        _logger.WriteLog("File Not Found 2");
                        Environment.Exit(6);
                    }

                }
            }
        }

        private string BuildEmailBody(string errorMessage)
        {
            StringBuilder sb = new StringBuilder("Errors Occured:");
            sb.Append("\nDate=");
            sb.Append(DateTime.Now.ToShortDateString());
            sb.Append("\nError#=");
            sb.Append(0);
            sb.Append("\nError Desc.=");
            sb.Append(errorMessage);
            sb.Append("\nOn Script=ProcessPDFOutPackage\n");
            return sb.ToString();
        }

        private void SendError(string message, SqlConnection connection)
        {
            EmailMergeFields fields = new EmailMergeFields();

            string sender = _packageConfiguration.mailSenderWebmaster;
            string senderName = "icix packages";
            string subject = "iCiX | Error ";// & now()
            string msgToEmail = _packageConfiguration.mailSenderWebmaster;
            string msgToName = "webmaster";
#if LOCALPATHFORSAN
            msgToEmail = "aliya.soultanova@icix.com"; 
            msgToName = "Aliya Soultanova";
#endif
            string emailSubject = "iCiX | Error ";
            string emailBody = message;//create Template Text message

            // Process Email and iCiX InBox Message 
            MailboxTableAdapter mailBoxAdapter = DataSqlAdaptersFactory.GetAdapter<MailboxTableAdapter>(connection);

            // Insert email details into tblMailBox table and return new created message id(scope_identity())
            int newMessageId = mailBoxAdapter.Insert(0, DateTime.Now, emailSubject, null, emailBody);
            newMessageId = (int)mailBoxAdapter.GetLastInsertedMessageId(0, emailSubject);

            // Insert mail into tblMessageList
            MessageListTableAdapter messageListAdapter = DataSqlAdaptersFactory.GetAdapter<MessageListTableAdapter>(connection);
            messageListAdapter.Insert(newMessageId, 0, (int)MailBoxMessagesDataSet.MessageListRow.ReceipientTypeValues.Something2, false);

            // Write email to be sent by DTS
            OrgEmailOutTableAdapter emailAdapter = DataSqlAdaptersFactory.GetAdapter<OrgEmailOutTableAdapter>(connection);
            emailAdapter.InsertEmailIdForTOCCAndBCCIntoDatabase(0, -1, 0, 0, sender, senderName, msgToEmail, msgToName,
                null, null, subject, emailBody, 0, null, ConstThisClassName);

        }

        private void AddFileToQuarantine(DocumentDataSet.FindDocumentRecordByFileNameRow documentsRow,
                                             FileInfo fileInfo, SqlConnection connection)
        {
            try
            {
                QuarantineFileTableAdapter quarantineFileTableAdapter = DataSqlAdaptersFactory.GetAdapter<QuarantineFileTableAdapter>(connection);
                quarantineFileTableAdapter.AddNewQuarantinedFile(documentsRow.docTypeId, fileInfo.Name.ToLower(), (int)fileInfo.Length,
                                                                 fileInfo.Extension, documentsRow.primaryDocId, documentsRow.orgId);
            }
            catch (Exception ex)
            {
                throw new Exception(new StringBuilder("UpdateDocumentFileStatus has failed.. File ").Append(fileInfo.Name.ToLower()).Append(" ErrorMessage: ").Append(ex.Message).ToString());
            }
        }

        private void SaveNewBinaryFileToDataBase(FileHandler filehandler, FindDocumentRecordByFileNameTableAdapter docFindTableAdapter,
                                                 DocumentDataSet.FindDocumentRecordByFileNameRow documentsRow,
                                                 FileInfo fileInfo, SqlConnection connection)
        {
            byte[] fileData = new byte[fileInfo.Length];
            try
            {
#if USENETWORK
                fileData = filehandler.GetBinaryFileFromNetwork(fileInfo.FullName, _packageConfiguration.SANNetworkUserIdentity);
#else
                fileData = filehandler.GetBinaryFile(fileInfo.FullName);
#endif
                docFindTableAdapter.UploadPDFDocumentToDatabase(documentsRow.primaryDocId, documentsRow.tableSource, fileInfo.Name.ToLower(),
                                                                (int)fileInfo.Length, (int)DocumentFileStatus.Available, fileData);
            }
            catch (Exception ex)
            {
                fileData = null;
                SendError(BuildEmailBody(new StringBuilder("ProcessPDFOutPackage tried to insert a file which appears not to have a document record.\n    File is ").Append(fileInfo.FullName).ToString()), connection);
                _logger.WriteLog(new StringBuilder("Error: SaveNewBinaryFileToDataBase has failed. File ").Append(fileInfo.Name.ToLower()).Append(" ErrorMessage: ").Append(ex.Message).ToString());
                throw new Exception(new StringBuilder("SaveNewBinaryFileToDataBase has failed. File ").Append(fileInfo.Name.ToLower()).Append(" ErrorMessage: ").Append(ex.Message).ToString());
            }
        }

        private void ProcessNonFoundFile(FileInfo nonFoundFileInfo, DocumentTypesDataSet.DocTypesRow docTypesRow, SqlConnection connection)
        {
            FileHandler fileHandler = new FileHandler();
            //Records for this document is not found in Database

            string destinationDirectory = docTypesRow.deadPath;

#if LOCALPATHFORSAN
            destinationDirectory = @"C:\iCiXLocalMachineSan\ProcessPDFOutPackage Test\deadPath\";
#endif

#if USENETWORK
            fileHandler.MoveFileToNetwork(nonFoundFileInfo.FullName, destinationDirectory, nonFoundFileInfo.Name.ToLower(),
                                              _packageConfiguration.SANNetworkUserIdentity);
#else
            fileHandler.MoveFile(nonFoundFileInfo.FullName, destinationDirectory, nonFoundFileInfo.Name.ToLower());
#endif
            _logger.WriteLog(new StringBuilder("ProcessPdfOutPackage found Dead file: ").Append(nonFoundFileInfo.FullName).Append(". File has been moved to ").Append(destinationDirectory).ToString());
            SendError(BuildEmailBody(new StringBuilder("ProcessPdfOutPackage found Dead file: ").Append(nonFoundFileInfo.FullName).Append(".     \nFile has been moved to ").Append(destinationDirectory).ToString()), connection);
        }

    }
}
