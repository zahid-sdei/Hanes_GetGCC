﻿using System;
using System.Data;
using System.Data.SqlClient;

using iCiX.DTS.Data;
using iCiX.DTS.Data.COCDataSetTableAdapters;
using iCiX.DTS.Data.ShipmentDataSetTableAdapters;
using iCiX.FrameWork.Data;
using System.Collections.Generic;

namespace iCiX.Execution.Packages
{
    /// <summary>
    /// Goes over the list of shipments that aready for processing. Validates the ability of COC creation for each and 
    /// creates a task if it can be done.
    /// </summary>
    public class ProcessShipmentsPackage : BasePackage
    {
        private const string ConstThisClassName = "ProcessShipmentsPackage";

        //stores shipments where shipment had Facility Not Found error and the shipment was fixed to be associated with a shipment
        //this is necessary because the loops are by shipment product but the update is on the shipment level, we only need to do
        //the update once per shipment
        private Dictionary<long, int> _facilityNotFoundFixedShipments = new Dictionary<long, int>();

        public ProcessShipmentsPackage(PackageConfiguration packageConfiguration) : base(packageConfiguration, ConstThisClassName) { }

        public override int Execute()
        {
            int executionResult = 0;
            _logger.WriteLog("Started");

            executionResult = this.Run();

            _logger.WriteLog("Done");
            return executionResult;
        }
        
        private int Run()
        {
            int executionResult = 0;

            SqlConnection connection = null;

            try
            {
                connection = new SqlConnection(_sqlConnectionString);
                connection.Open();

                ShipmentProductVTableAdapter adapter = DataSqlAdaptersFactory.GetAdapter<ShipmentProductVTableAdapter>(connection);
                ShipmentDataSet.ShipmentProductVDataTable shipmentRecords = adapter.GetData(
                    _packageConfiguration.ShipmentsDestinationOrgIdForCertificate,
                    (_packageConfiguration.ShipmentReadinessCheckFrequency * 60),
                    DateTime.Now,
                    _packageConfiguration.ShipmentReadinessMaxDaysBack);

                if (shipmentRecords.Count == 0)
                    _logger.WriteLog("Nothing to do");
                else
                    executionResult = ValidateShipments(shipmentRecords, connection);

                connection.Close();
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex, "Run");
                executionResult = 0;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }
            return executionResult;
        }

        private int ValidateShipments(ShipmentDataSet.ShipmentProductVDataTable shipmentRecords, SqlConnection connection)
        {
            int executionResult = 0;

            foreach (ShipmentDataSet.ShipmentProductVRow row in shipmentRecords)
                executionResult = ValidateShipmentLine(row, connection);

            return executionResult;
        }

        private int ValidateShipmentLine(ShipmentDataSet.ShipmentProductVRow shipmentRow, SqlConnection connection)
        {
            int executionResult = 0;
            SqlTransaction transaction = null;
            
            try
            {
                transaction = connection.BeginTransaction(IsolationLevel.RepeatableRead);

                bool canCOCBeCreated = false;
                
                //if shipment is not associated with an org then try to associate it
                if (shipmentRow.IsshipmentOrgIdNull() || shipmentRow.shipmentOrgId == 0)
                {
                    //if the shipment has already been fixed then set the certificate status to Processing and continue on
                    if (_facilityNotFoundFixedShipments.ContainsKey(shipmentRow.shipmentId))
                    {
                        //the facility was associated, the next step is to link the shipping product to a product at the facility
                        shipmentRow.shipmentProductCertificateStatusId = (int)ShipmentDataSet.ShipmentCertificateStatus.ProductNotFound;
                        shipmentRow.shipmentOrgId = _facilityNotFoundFixedShipments[shipmentRow.shipmentId];
                    }
                    else if (!shipmentRow.IsshipmentVendorNumberNull())
                    {
                        ShipmentProductTableAdapter venderNumberShipmentProductAdapter = DataSqlAdaptersFactory.GetAdapter<ShipmentProductTableAdapter>(transaction);
                        int supplierOrgId = venderNumberShipmentProductAdapter.GetShipmentSupplierOrgId(shipmentRow.shipmentDestinationOrgId, shipmentRow.shipmentVendorNumber.Trim());
                        if (supplierOrgId > 0)
                        {
                            ShipmentProductVTableAdapter shipmentProductVAdapter = DataSqlAdaptersFactory.GetAdapter<ShipmentProductVTableAdapter>(transaction);
                            shipmentProductVAdapter.UpdateSupplierOrgId(supplierOrgId, shipmentRow.shipmentId);

                            shipmentRow.shipmentOrgId = supplierOrgId;
                            _facilityNotFoundFixedShipments.Add(shipmentRow.shipmentId, supplierOrgId);

                            //the facility was associated, the next step is to link the shipping product to a product at the facility
                            shipmentRow.shipmentProductCertificateStatusId = (int)ShipmentDataSet.ShipmentCertificateStatus.ProductNotFound;
                        }
                        else
                        {
                            shipmentRow.shipmentProductCertificateStatusId = (int)ShipmentDataSet.ShipmentCertificateStatus.FacilityNotFound;
                        }
                    }
                }

                int supplierShipmentCertificateStatusId = shipmentRow.shipmentProductCertificateStatusId;
                int shipmentProductDocId = 0;
                if (supplierShipmentCertificateStatusId != (int)ShipmentDataSet.ShipmentCertificateStatus.FacilityNotFound)
                {
                    if (shipmentRow.IsshipmentProductDocIdNull() || shipmentRow.shipmentProductDocId == 0)
                    {
                        if (shipmentRow.shipmentProductCertificateStatusId == (int)ShipmentDataSet.ShipmentCertificateStatus.ProductNotFound)
                        {
                            //try to find a document for this shipment product and if found, update docId of the shipment product record
                            ShipmentProductTableAdapter shipmentProductAdapter = DataSqlAdaptersFactory.GetAdapter<ShipmentProductTableAdapter>(transaction);
                            shipmentProductDocId = shipmentProductAdapter.LinkShipmentToDocumentBySKU(shipmentRow.shipmentDestinationOrgId, shipmentRow.shipmentOrgId, shipmentRow.shipmentProductRecordCode);

                            shipmentRow.shipmentProductDocId = shipmentProductDocId;
                            if (shipmentRow.shipmentProductDocId > 0)
                                shipmentProductAdapter.UpdateDocId(shipmentRow.shipmentProductDocId, shipmentRow.shipmentProductId);
                        }
                    }
                    else
                    {
                        shipmentProductDocId = shipmentRow.shipmentProductDocId;
                    }
                    
                    COCShipmentProductTableAdapter cocShipmentAdapter = DataSqlAdaptersFactory.GetAdapter<COCShipmentProductTableAdapter>(transaction);
                    COCShipmentProductTableAdapter.COCValidationResults validationResults = cocShipmentAdapter.ValidateShipment(shipmentProductDocId);
                    supplierShipmentCertificateStatusId = validationResults.CertificateStatusId;
                    canCOCBeCreated = validationResults.CanBeCreated;
                }

                _logger.WriteLog("Processing shipmentProductDocId = " + shipmentProductDocId + ", shipmentProductId = " + shipmentRow.shipmentProductId, " ValidateShipmentLine");
                 
                if (supplierShipmentCertificateStatusId == 0) throw new Exception("Invalid Certificate Status.");

                ShipmentProductVTableAdapter adapter = DataSqlAdaptersFactory.GetAdapter<ShipmentProductVTableAdapter>(transaction);
                adapter.UpdateLastValidationDateAndStatus(DateTime.Now, supplierShipmentCertificateStatusId, shipmentRow.shipmentProductId);

                if (canCOCBeCreated)
                {
                    COCCertificateTableAdapter cocAdapter = DataSqlAdaptersFactory.GetAdapter<COCCertificateTableAdapter>(transaction);
                    cocAdapter.CreateCOC(shipmentProductDocId, (int)shipmentRow.shipmentProductId);                    
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                _logger.WriteLog(ex, "ValidateShipmentLine");
                executionResult = 0;
            }

            return executionResult;
        }
    }
}
