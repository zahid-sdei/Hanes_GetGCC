﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

using iCiX.DTS.Data;
using iCiX.DTS.Data.AutomatedTasksDataSetTableAdapters;
using iCiX.FrameWork.Core.AutomatedTasks;
using iCiX.FrameWork.Data;
using iCiX.DTS.Data.ShipmentDataSetTableAdapters;
using iCiX.FrameWork.Core;

namespace iCiX.Execution.Packages
{
    public class COCCreationServicePackage : BasePackage
    {
        private const string ConstThisClassName = "COCCreationServicePackage";
        private const int ConstRecordLimit = 500;

        private int _automatedTaskItemId;

        public COCCreationServicePackage(PackageConfiguration packageConfiguration, int automatedTaskItemId)
            : base(packageConfiguration, ConstThisClassName)
        {
            this._automatedTaskItemId = automatedTaskItemId;
        }

        public override int Execute()
        {
            int executionResult = 0;
            _logger.WriteLog("Started automatedTaskItemId = " + _automatedTaskItemId);

            executionResult = this.Run();

            _logger.WriteLog("Done automatedTaskItemId = " + _automatedTaskItemId);
            return executionResult;
        }

        private int Run()
        {
            int executionResult = 0;

            SqlConnection connection = null;

            try
            {
                connection = new SqlConnection(_sqlConnectionString);
                connection.Open();

                AutomatedTaskItemsTableAdapter adapter = DataSqlAdaptersFactory.GetAdapter<AutomatedTaskItemsTableAdapter>(connection);

                AutomatedTasksDataSet.AutomatedTaskItemsDataTable docsData =
                    (_automatedTaskItemId == 0) ? adapter.GetLimitedNewAutomatedTaskItemsByType(ConstRecordLimit,
						(int)AutomatedTaskTypes.CreateCOC)
                            : adapter.GetData(_automatedTaskItemId);

                if (docsData.Count == 0)
                    _logger.WriteLog("Nothing to do");
                else
                    executionResult = ProcessDocuments(docsData, connection);

                connection.Close();
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex, "Error: Run");
                executionResult = 0;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }
            return executionResult;
        }

        public int ProcessDocuments(AutomatedTasksDataSet.AutomatedTaskItemsDataTable docsData, SqlConnection connection)
        {
            int executionResult = 0;

            foreach (AutomatedTasksDataSet.AutomatedTaskItemsRow automatedItemRow in docsData)
                executionResult = ProcessDocument(automatedItemRow, connection);

            return executionResult;
        }

        public int ProcessDocument(AutomatedTasksDataSet.AutomatedTaskItemsRow automatedItemRow, SqlConnection connection)
        {
            int executionResult = 0;
            SqlTransaction transaction = null;

            try
            {
                transaction = connection.BeginTransaction(IsolationLevel.RepeatableRead);

                if (automatedItemRow.itemId == 0) throw new Exception("The docId is not set.");
                if (automatedItemRow.IsitemReference1Null()) throw new Exception("The file name is not set.");
                if (automatedItemRow.Isitem6Null()) throw new Exception("The rtf is not set.");

                long docId = automatedItemRow.itemId;
                string fileName = automatedItemRow.itemReference1;
                string rtf = automatedItemRow.item6;
                string destinationDirectory = GetCertificateDocumentOriginalsPath(transaction);

                string destinationFullPath = destinationDirectory + @"\" + fileName;

                long supplierShipmentXProductsId = 0;
                if (!automatedItemRow.IsitemId1Null()) supplierShipmentXProductsId = automatedItemRow.itemId1;

                _logger.WriteLog("creating COC for docId = " + docId, " ProcessDocument");

                TextWriter writeFile = new StreamWriter(destinationFullPath);
                writeFile.Write(rtf);
                writeFile.Flush();
                writeFile.Close();
                writeFile = null;

                // commenting and trying to get away with simple text file creation since we know this is rtf.
                // int fileCreateReturnValue = FileHandler.CreateFileOnNetwork(rtf, destinationFullPath, _packageConfiguration.SANNetworkUserIdentity);
                // if (fileCreateReturnValue != 1) throw new Exception("Problem creating file on network: " + destinationFullPath);

                if (supplierShipmentXProductsId > 0)
                {
                    //if the record came from a shipment then update the status 
                    //and certificateDocId of the tblSupplierShipmentXProducts record
                    ShipmentProductVTableAdapter shipmentProductsAdapter =
                            DataSqlAdaptersFactory.GetAdapter<ShipmentProductVTableAdapter>(transaction);
                    shipmentProductsAdapter.UpdateCertDocIdAndStatus(
                        (int)docId,
                        (int)ShipmentDataSet.ShipmentCertificateStatus.CertificateCreated,
                        supplierShipmentXProductsId);

                    _logger.WriteLog("tblSupplierShipmentXProducts.SupplierShipmentXProductsId = " + supplierShipmentXProductsId +
                            " is updated to Certificate Created ", "ProcessDocument");
                }

                // mark automated task as complete
                AutomatedItemsDocumentFilesCopyTableAdapter itemAdapter =
                    DataSqlAdaptersFactory.GetAdapter<AutomatedItemsDocumentFilesCopyTableAdapter>(transaction);
                itemAdapter.UpdateAutomatedTaskItem(automatedItemRow.automatedTaskItemId, (int)AutomatedTasksDataSet.AutomatedTaskItemStatus.Complete,
                    DateTime.Now, ConstThisClassName, "Done");

                transaction.Commit();
            }
            catch (Exception ex)
            {
                _logger.WriteLog(ex.StackTrace);
                transaction.Rollback();
                _logger.WriteLog(ex, "Error: ProcessDocument");
                executionResult = 0;
            }

            return executionResult;
        }
    }
}