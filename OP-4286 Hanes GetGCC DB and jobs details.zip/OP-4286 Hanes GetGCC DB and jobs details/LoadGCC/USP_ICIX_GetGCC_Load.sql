--sp_helptext USP_ICIX_GetGCC_Load_V2


CREATE PROCEDURE dbo.USP_ICIX_GetGCC_Load_V2
(
	@orgId INT = 18369
)
AS
BEGIN

	SET NOCOUNT ON
	
	--TRUNCATE TABLE tblHanesGetGCCTableStep1
	--TRUNCATE TABLE tblHanesGetGCCTableStep2
	--TRUNCATE TABLE tblHanesGetGCCTableStep3
		
	--dateAdded is shown as the manufacture date, we need to take this from the
	--shipment date, if there is no shipment and the certificate was created
	--manually then we can get it from the tblManualCoC table. If there's no
	--record there then just use date added.
	
	INSERT INTO tblHanesGetGCCTableStep1 (docId, linkedDocId, orgId, dateAdded)
	SELECT d.docId, d.linkedDocId, d.orgId, 
		COALESCE(s.shipmentDate, mc.manufactureDate, d.dateAdded) dateAdded
	FROM tbldocs d WITH(NOLOCK)
		LEFT JOIN tblSupplierShipmentXProducts sp WITH (NOLOCK)
			ON d.docId = sp.certificateDocId
		LEFT JOIN tblSupplierShipments s WITH (NOLOCK)
			ON s.supplierShipmentId = sp.supplierShipmentId
		LEFT JOIN tblManualCoC mc WITH (NOLOCK)
			ON d.docId = mc.docId
		LEFT JOIN tblHanesGetGCCTableStep1 pc WITH (NOLOCK) 
			ON pc.docId = d.docId AND pc.linkedDocId = d.linkedDocId AND pc.orgId = d.orgId
	WHERE d.docTypeId = 1
		AND d.title = 'CPSIA Certificate of Compliance'
		AND pc.docId IS NULL

	PRINT 'New CPSIA COC Certificates created & tblHanesGetGCCTableStep1 : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)

	INSERT INTO tblHanesGetGCCTableStep2 (cocDocId, cocDocOrgId, linkedDocId, dateAdded,
		supplierProductDocId, hanesProductDocId)
	SELECT d.docId, d.orgId, d.linkedDocId, d.dateAdded, d1.docId linkDocDocId, d1.approvedProductDocId
	FROM tblHanesGetGCCTableStep1 d WITH (NOLOCK)
		JOIN tblDocs d1 WITH (NOLOCK)
			ON d1.docId = d.linkedDocId
		LEFT JOIN tblHanesGetGCCTableStep2 pc WITH (NOLOCK) 
			ON pc.cocDocId = d.docId AND pc.linkedDocId = d.linkedDocId AND pc.cocDocOrgId = d.orgId
	WHERE pc.cocDocId IS NULL
	
	PRINT 'New rows inserted into tblHanesGetGCCTableStep2 table : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)
		
	INSERT INTO tblHanesGetGCCTableStep3 (certId, fileName, certDocId, 
		filesize, Filestatus)
	SELECT
		c.certId, c.fileName, c.certDocId, c.filesize,
		c.Filestatus
	FROM
		tblHanesGetGCCTableStep2 d WITH (NOLOCK)
			JOIN tblCertDocs c WITH (NOLOCK) ON d.cocDocId = c.certid
			LEFT JOIN tblHanesGetGCCTableStep3 pc WITH (NOLOCK) ON c.certId = pc.certId AND c.certDocId = pc.certDocId
	WHERE c.title = 'CPSIA Certificate of Compliance' AND c.certDocType = 'mainDoc'
		AND pc.certId IS NULL

	PRINT 'New rows inserted into tblHanesGetGCCTableStep3 table : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)

	UPDATE tblHanesGetGCCTableStep3 
		SET fileStatus = c.fileStatus, 
			fileSize = c.fileSize
	FROM tblHanesGetGCCTableStep3 h WITH (NOLOCK) 
		JOIN tblCertDocs c (NOLOCK) ON c.certId = h.certId 
			AND c.certDocId = h.certDocId
	WHERE h.Filestatus = 0 AND h.fileSize = 0
		AND c.Filestatus = 3 AND c.fileSize > 0

	PRINT 'Updating fileStatus & fileSize into tblHanesGetGCCTableStep3 from tblCertDocs table : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)


	--TRUNCATE TABLE tblHanesGetGCCSearch
	
	INSERT INTO tblHanesGetGCCSearch (cocDocId, cocDocOrgId, linkedDocId, dateAdded,
		supplierProductDocId, hanesProductDocId, certDescription, 
		productCategory, manufacturingStyle, hanesTitle, upc, businessUnit, colorDescription)
	SELECT d.cocDocId, d.cocDocOrgId, d.linkedDocId, d.dateAdded, d.supplierProductDocId, 
		d.hanesProductDocId, d2.certDescription, ped.productCategory, 
		d2.manufacturingStyle, d2.title hanesTitle, 
		d2.upc, ped.businessUnit, ped.colorDescription
	FROM tblHanesGetGCCTableStep2 d WITH(NOLOCK)
		JOIN tbldocs d2 WITH(NOLOCK)
			ON d2.docId = d.hanesProductDocId
		JOIN tblProductExtraData ped WITH(NOLOCK) 
			ON d2.docId = ped.docId
		LEFT JOIN tblHanesGetGCCSearch pc 
			ON pc.cocDocId = d.cocDocId AND pc.cocDocOrgId = d.cocDocOrgId AND pc.linkedDocId = d.linkedDocId
	WHERE pc.cocDocId IS NULL AND d2.orgId = @orgId

	PRINT 'New rows inserted into tblHanesGetGCCSearch table : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)
	
	--TRUNCATE TABLE tblHanesGetGCCSearchUPC

	INSERT INTO tblHanesGetGCCSearchUPC (cocDocId, cocDocOrgId, linkedDocId, dateAdded,
		supplierProductDocId, hanesProductDocId, certDescription, 
		productCategory, manufacturingStyle, hanesTitle, upc, businessUnit, colorDescription)
	SELECT g.cocDocId, g.cocDocOrgId, g.linkedDocId, g.dateAdded,
		g.supplierProductDocId, g.hanesProductDocId, g.certDescription, 
		g.productCategory, g.manufacturingStyle, g.hanesTitle, g.upc, g.businessUnit, g.colorDescription
	FROM tblHanesGetGCCSearch g WITH (NOLOCK)
		LEFT JOIN tblHanesGetGCCSearchUPC u WITH (NOLOCK) 
			ON g.cocDocId = u.cocDocId 
				AND g.cocDocOrgId = u.cocDocOrgId
				AND g.linkedDocId = u.linkedDocId
	WHERE u.cocDocId IS NULL
	
	PRINT 'New rows inserted into tblHanesGetGCCSearchUPC table : ' + CONVERT(VARCHAR(10), @@ROWCOUNT)
END
GO