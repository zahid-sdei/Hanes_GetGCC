

--'Selling Style # search
	SELECT DISTINCT TOP 4000 cocDocId [docId], 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus,
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], city, state, country, colorDescription, certDescription,
		productCategory, manufacturingStyle, dbo.UDF_Hanes_GetProductCodeValue(d.hanesProductDocId) productCode
	FROM tblHanesGetGCCSearch d WITH(NOLOCK)
		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid 
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certid
		WHERE CONTAINS(hanesTitle, '" & delimitedTitleSearchTerm & "')

	UNION
	
	SELECT DISTINCT TOP 4000 cocDocId [docId], 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus,
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], city, state, country, colorDescription, certDescription,
		productCategory, manufacturingStyle, CASE pc.productCodeTypeId WHEN 8 THEN pc.productCode ELSE '' END productCode
	FROM tblHanesGetGCCSearch d WITH(NOLOCK)
		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid 
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certid
		JOIN tblProductCodes pc WITH(NOLOCK)
			ON d.hanesProductDocId = pc.docId AND productCodeTypeId IN (7, 8)
	--WHERE 
	--and below search condition added in page
	--" & delimitedProductCodeBusinessUnitSearchClause & " " & delimitedProductCodeSearchClauseExhaustive & " NOT CONTAINS(hanesTitle, '" & delimitedTitleSearchTerm & "')"
	


-- 'UPC Number search search
	SELECT DISTINCT TOP 4000 cocDocId, 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus, 
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], upc [upcNumber], city, state, country, colorDescription, productCategory,
		dbo.UDF_Hanes_GetProductCodeValue(d.hanesProductDocId) productCode
	FROM tblHanesGetGCCSearchUPC d WITH(NOLOCK)
		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certid
	WHERE CONTAINS(upc, '" & delimitedTitleSearchTerm & "')

	UNION

	SELECT DISTINCT TOP 4000 cocDocId, 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus,
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], pc.productCode [upcNumber], city, state, country, colorDescription, productCategory,
		CASE pc.productCodeTypeId WHEN 8 THEN pc.productCode ELSE '' END productCode
	FROM tblHanesGetGCCSearchUPC d WITH(NOLOCK)
		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certid
		JOIN tblProductCodes pc WITH(NOLOCK)
			ON d.hanesProductDocId = pc.docId AND productCodeTypeId = 9
	--WHERE 
	--and below search condition added in code
	--" & delimitedProductCodeBusinessUnitSearchClause & " " & delimitedProductCodeSearchClause & " NOT CONTAINS(upc, '" & delimitedTitleSearchTerm & "')"
		


  --Manufacturing Style # search
	
	SELECT DISTINCT TOP 4000 cocDocId [docId], 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus,
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], hanesTitle [hanesProductID], city, state, country, colorDescription, productCategory,
		dbo.UDF_Hanes_GetProductCodeValue(d.hanesProductDocId) productCode
	FROM tblHanesGetGCCSearch d WITH(NOLOCK)
		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid 
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certid
	WHERE CONTAINS(hanesTitle, '" & delimitedTitleSearchTerm & "')
	
	UNION
	
	SELECT DISTINCT TOP 4000 cocDocId [docId], 'Certificates of Compliance' [certTitle], fileName, certDocId, filesize, filestatus,
		CONVERT(varchar(10), d.dateAdded, 101) [certDateAddedDisplay], d.productCode [hanesProductID], city, state, country,
		colorDescription, productCategory, CASE d.productCodeTypeId WHEN 8 THEN d.productCode ELSE '' END productCode 
	FROM
        (
	        --It can contain duplicate records so returning more than 4000 records
	        --duplicates will be filtered out in the outer query by DISTINCT
	        SELECT TOP 10000 d.cocDocId, d.dateAdded, d.colorDescription, d.productCategory, d.cocDocOrgId, pc.productCode, pc.productCodeTypeId
			FROM tblHanesGetGCCSearch d WITH(NOLOCK)
				JOIN tblProductCodes pc WITH(NOLOCK) ON d.hanesProductDocId = pc.docId AND productCodeTypeId IN (6, 8)
			
			--Below serach condition added in page
			--WHERE " & delimitedProductCodeBusinessUnitSearchClause & " " & delimitedProductCodeSearchClause & " NOT CONTAINS(hanesTitle, '" & delimitedTitleSearchTerm & "')" & vbNewLine & _
			ORDER BY d.dateAdded DESC
        ) d 

		JOIN tblOrgs o WITH(NOLOCK) ON d.cocDocOrgId = o.orgid 
		JOIN tblCountries cn WITH(NOLOCK) ON o.countryCode = cn.countryCode 
		JOIN tblHanesGetGCCTableStep3 c WITH(NOLOCK) ON d.cocDocId = c.certId 

