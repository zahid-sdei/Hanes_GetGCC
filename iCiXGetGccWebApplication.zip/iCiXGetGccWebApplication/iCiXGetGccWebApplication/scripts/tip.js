﻿<!-- 
var MI_IE=MI_IE4=MI_NN4=MI_ONN=MI_NN=MI_pSub=MI_sNav=0;mig_dNav()
var Style=[],Text=[],Count=0,move=0,fl=0,isOK=1,hs,e_d,tb,w=window,PX=(MI_pSub)?"px":""
var d_r=(MI_IE&&document.compatMode=="CSS1Compat")? "document.documentElement":"document.body"
var ww=w.innerWidth
var wh=w.innerHeight
var sbw=MI_ONN? 15:0
var closeImg
var extend = false


function extendNow() {
    extend = true

}

function extendEnd() {
    extend = false

}

function checkHide() {

if (extend) 
    setTimeout('checkHide()',5000)
else
    mig_hide(1);    

}
function mig_hand(){
if(MI_sNav){
w.onresize=mig_re
document.onmousemove=mig_mo
if(MI_NN4) document.captureEvents(Event.MOUSEMOVE)
}}		

function mig_dNav(){
var ua=navigator.userAgent.toLowerCase()
MI_pSub=navigator.productSub
MI_OPR=ua.indexOf("opera")>-1?parseInt(ua.substring(ua.indexOf("opera")+6,ua.length)):0
MI_IE=document.all&&!MI_OPR?parseFloat(ua.substring(ua.indexOf("msie")+5,ua.length)):0
MI_IE4=parseInt(MI_IE)==4
MI_NN4=navigator.appName.toLowerCase()=="netscape"&&!document.getElementById
MI_NN=MI_NN4||document.getElementById&&!document.all
MI_ONN=MI_NN4||MI_pSub<20020823
MI_sNav=MI_NN||MI_IE||MI_OPR>=7
}


function mig_cssf(){
if(MI_IE>=5.5&&FiltersEnabled){fl=1
var d=" progid:DXImageTransform.Microsoft."
mig_layCss().filter="revealTrans()"+d+"Fade(Overlap=1.00 enabled=0)"+d+"Inset(enabled=0)"+d+"Iris(irisstyle=PLUS,motion=in enabled=0)"+d+"Iris(irisstyle=PLUS,motion=out enabled=0)"+d+"Iris(irisstyle=DIAMOND,motion=in enabled=0)"+d+"Iris(irisstyle=DIAMOND,motion=out enabled=0)"+d+"Iris(irisstyle=CROSS,motion=in enabled=0)"+d+"Iris(irisstyle=CROSS,motion=out enabled=0)"+d+"Iris(irisstyle=STAR,motion=in enabled=0)"+d+"Iris(irisstyle=STAR,motion=out enabled=0)"+d+"RadialWipe(wipestyle=CLOCK enabled=0)"+d+"RadialWipe(wipestyle=WEDGE enabled=0)"+d+"RadialWipe(wipestyle=RADIAL enabled=0)"+d+"Pixelate(MaxSquare=35,enabled=0)"+d+"Slide(slidestyle=HIDE,Bands=25 enabled=0)"+d+"Slide(slidestyle=PUSH,Bands=25 enabled=0)"+d+"Slide(slidestyle=SWAP,Bands=25 enabled=0)"+d+"Spiral(GridSizeX=16,GridSizeY=16 enabled=0)"+d+"Stretch(stretchstyle=HIDE enabled=0)"+d+"Stretch(stretchstyle=PUSH enabled=0)"+d+"Stretch(stretchstyle=SPIN enabled=0)"+d+"Wheel(spokes=16 enabled=0)"+d+"GradientWipe(GradientSize=1.00,wipestyle=0,motion=forward enabled=0)"+d+"GradientWipe(GradientSize=1.00,wipestyle=0,motion=reverse enabled=0)"+d+"GradientWipe(GradientSize=1.00,wipestyle=1,motion=forward enabled=0)"+d+"GradientWipe(GradientSize=1.00,wipestyle=1,motion=reverse enabled=0)"+d+"Zigzag(GridSizeX=8,GridSizeY=8 enabled=0)"+d+"Alpha(enabled=0)"+d+"Dropshadow(OffX=3,OffY=3,Positive=true,enabled=0)"+d+"Shadow(strength=3,direction=135,enabled=0)"
}}

function stm(t,s, ctrlToHide){
if(MI_sNav&&isOK){	
if(document.onmousemove!=mig_mo||w.onresize!=mig_re) mig_hand()
if(fl&&s[17]>-1&&s[18]>0)mig_layCss().visibility="hidden"
var ab="";var ap=""	
var titCol=s[0]?"COLOR='"+s[0]+"'":""
var titBgCol=s[1]&&!s[2]?"BGCOLOR='"+s[1]+"'":""
var titBgImg=s[2]?"BACKGROUND='"+s[2]+"'":""
var titTxtAli=s[3]?"ALIGN='"+s[3]+"'":""
var txtCol=s[6]?"COLOR='"+s[6]+"'":""
var txtBgCol=s[7]&&!s[8]?"BGCOLOR='"+s[7]+"'":""
var txtBgImg=s[8]?"BACKGROUND='"+s[8]+"'":""
var txtTxtAli=s[9]?"ALIGN='"+s[9]+"'":""
var tipHeight=s[13]? "HEIGHT='"+s[13]+"'":""
var brdCol=s[15]? "BGCOLOR='"+s[15]+"'":""
if(!s[4])s[4]="Verdana,Arial,Helvetica" 
if(!s[5])s[5]=1 
if(!s[10])s[10]="Verdana,Arial,Helvetica" 
if(!s[11])s[11]=1
if(!s[12])s[12]=200
if(!s[14])s[14]=0
if(!s[16])s[16]=0
if(!s[24])s[24]=10
if(!s[25])s[25]=10
hs=s[22]
if(MI_pSub==20001108){
if(s[14])ab="STYLE='border:"+s[14]+"px solid"+" "+s[15]+"'";
ap="STYLE='padding:"+s[16]+"px "+s[16]+"px "+s[16]+"px "+s[16]+"px'"}
//Link for close
var closeLink="<A HREF='javascript:void(0)' ONCLICK='mig_hide(0)'><B><img src='images/UI/close_icon.gif' border='0' width='14' height='28' title='Close'/></B></A>"
//ToolTip Heading
var headingTr="<tr><td width='10'><img src='images/UI/header_lt.gif' width='10' alt='' /></td><td background='images/UI/header_mid.gif' ></td><td background='images/UI/header_mid.gif' nowrap valign='center' align='left' width='100%'>"
headingTr=headingTr+t[0]+"</td>"
headingTr=headingTr+"<td background='images/UI/header_mid.gif' width='14' align='right'>"+closeLink+"</td>"
headingTr=headingTr+"<td width='10'><img src='images/UI/header_rt.gif' width='10' alt='' /></td></tr>"
//ToolTip Bottom
var strBottom="<tr><td valign='top'><img src='images/UI/bottom_l_crv.gif' alt='' width='10' height='9'/></td><td  colspan='3' width='100%' nowrap>"
//class='bottom_m_line'
//<img src='images/UI/tipBottom_r_crv.gif' alt='' height='9'/>width='600' height='9'
strBottom=strBottom+"<img src='images/UI/bottom_m_line.gif' alt='' width='100%' height='9'/></td><td ><img src='images/UI/tipBottom_r_crv.gif' alt=''/></td></tr>"

var title=t[0]||hs==3?"<TABLE WIDTH='100%' BORDER='0' CELLPADDING='0' CELLSPACING='0' "+titBgCol+" "+titBgImg+"><TR><TD "+titTxtAli+"><FONT SIZE='"+s[5]+"' FACE='"+s[4]+"' "+titCol+"><B>"+t[0]+"</B></FONT></TD><TD><A HREF='javascript:void(0)' ONCLICK='mig_hide(0)' STYLE='text-decoration:none;color:"+s[0]+"'><B><img src='"+ closeImg +"' border='0' width='12'title='Close'/></B></A></TD></TR></TABLE>":"";
//var txt="<TABLE "+ab+" WIDTH='"+s[12]+"' BORDER='0' CELLSPACING='0' CELLPADDING='"+s[14]+"' "+brdCol+"><TR><TD>"+title+"<TABLE WIDTH='100%' "+tipHeight+" BORDER='0' CELLPADDING='"+s[16]+"' CELLSPACING='0' "+txtBgCol+" "+txtBgImg+"><TR><TD "+txtTxtAli+" "+ap+" VALIGN='top'><DIV ID=RDiv onMouseOver=Javascript:extendNow(); onMouseOut=Javascript:extendEnd(); STYLE='height:90px; overflow:Auto;'><TABLE WIDTH='100%'BORDER='0' CELLPADDING='"+s[16]+"' CELLSPACING='0'><TR><TD VALIGN='top'><FONT SIZE='"+s[11]+"' FACE='"+s[10]+"' "+txtCol +">"+t[1]+"</FONT></TD></TR></TABLE></Div></TD></TR></TABLE></TD></TR></TABLE>"
//ToolTip Table
var txt="<TABLE  WIDTH='198' BORDER='0' CELLSPACING='0' CELLPADDING='0'>"+headingTr+"<TR><TD class='left_line'></td><td colspan='3' background='images/UI/header_mid.gif'><TABLE WIDTH='100%' "+tipHeight+" BORDER='0' CELLPADDING='"+s[16]+"' CELLSPACING='0' "+txtBgCol+" "+txtBgImg+"><TR><TD "+txtTxtAli+" "+ap+" VALIGN='top'><DIV ID=RDiv onMouseOver=Javascript:extendNow(); onMouseOut=Javascript:extendEnd(); STYLE='height:90px; overflow:Auto;'><TABLE WIDTH='100%'BORDER='0' CELLPADDING='"+s[16]+"' CELLSPACING='0'><TR><TD VALIGN='top'><FONT SIZE='"+s[11]+"' FACE='"+s[10]+"' "+txtCol +">"+t[1]+"</FONT></TD></TR></TABLE></Div></TD></TR></TABLE></TD><TD align='left' class='msgRight_line'></TD></TR>"+strBottom+"</TABLE>"
mig_wlay(txt)
tb={trans:s[17],dur:s[18],opac:s[19],st:s[20],sc:s[21],pos:s[23],xpos:s[24],ypos:s[25]}
if(MI_IE4)mig_layCss().width=s[12]
e_d=mig_ed()
Count=0
move=1
	if(ctrlToHide != "undefined" && ctrlToHide != "")
	{
	  /*alert(ctrlToHide);*/
	  if(document.getElementById(ctrlToHide))
	  document.getElementById(ctrlToHide).style.display = "none";
	}
}}

function mig_mo(e){
if(move){
var X=0,Y=0,s_d=mig_scd(),w_d=mig_wd()
var mx=MI_NN?e.pageX:MI_IE4?event.x:event.x+s_d[0]
var my=MI_NN?e.pageY:MI_IE4?event.y:event.y+s_d[1]
if(MI_IE4)e_d=mig_ed()
switch(tb.pos){
case 1:X=mx-e_d[0]-tb.xpos+6;Y=my+tb.ypos;break
case 2:X=mx-(e_d[0]/2);Y=my+tb.ypos;break
case 3:X=tb.xpos+s_d[0];Y=tb.ypos+s_d[1];break
case 4:X=tb.xpos;Y=tb.ypos;break		
default:X=mx+tb.xpos;Y=my+tb.ypos}
if(w_d[0]+s_d[0]<e_d[0]+X+sbw)X=w_d[0]+s_d[0]-e_d[0]-sbw
if(w_d[1]+s_d[1]<e_d[1]+Y+sbw){if(tb.pos>2)Y=w_d[1]+s_d[1]-e_d[1]-sbw;else Y=my-e_d[1]}
if(X<s_d[0])X=s_d[0]
with(mig_layCss()){left=X+PX;top=Y+PX}
mig_dis()
}}

function mig_dis(){Count++
if(Count==1){
if(fl){	
if(tb.trans==51)tb.trans=parseInt(Math.random()*50)
var at=tb.trans>-1&&tb.trans<24&&tb.dur>0 
var af=tb.trans>23&&tb.trans<51&&tb.dur>0
var t=mig_lay().filters[af?tb.trans-23:0]
for(var p=28;p<31;p++){mig_lay().filters[p].enabled=0}
for(var s=0;s<28;s++){if(mig_lay().filters[s].status)mig_lay().filters[s].stop()}
for(var e=1;e<3;e++){if(tb.sc&&tb.st==e){with(mig_lay().filters[28+e]){enabled=1;color=tb.sc}}}
if(tb.opac>0&&tb.opac<100){with(mig_lay().filters[28]){enabled=1;opacity=tb.opac}}
if(at||af){if(at)mig_lay().filters[0].transition=tb.trans;t.duration=tb.dur;t.apply()}}
mig_layCss().visibility=MI_NN4?"show":"visible"
if(fl&&(at||af))t.play()
if(hs>0&&hs<4)move=0
}}

function mig_layCss(){return MI_NN4?mig_lay():mig_lay().style}
function mig_lay(){with(document)return MI_NN4?layers[TipId]:MI_IE4?all[TipId]:getElementById(TipId)}
function mig_wlay(txt){if(MI_NN4){with(mig_lay().document){open();write(txt);close()}}else mig_lay().innerHTML=txt}
function mig_hide(C){if(!MI_NN4||MI_NN4&&C)mig_wlay("");with(mig_layCss()){visibility=MI_NN4?"hide":"hidden";left=0;top=-800}}
function mig_scd(){return [parseInt(MI_IE?eval(d_r).scrollLeft:w.pageXOffset),parseInt(MI_IE?eval(d_r).scrollTop:w.pageYOffset)]}
function mig_re(){var w_d=mig_wd();if(MI_NN4&&(w_d[0]-ww||w_d[1]-wh))location.reload();else if(hs==3||hs==2) mig_hide(1)}
function mig_wd(){return [parseInt(MI_ONN?w.innerWidth:eval(d_r).clientWidth),parseInt(MI_ONN?w.innerHeight:eval(d_r).clientHeight)]}
function mig_ed(){return [parseInt(MI_NN4?mig_lay().clip.width:mig_lay().offsetWidth)+3,parseInt(MI_NN4?mig_lay().clip.height:mig_lay().offsetHeight)+5]}
function htm(ctrlToShow)
{
  if(MI_sNav&&isOK){if(hs!=4){move=0;if(hs!=3&&hs!=2){mig_hide(1)}}}
  if(ctrlToShow != "undefined" && ctrlToShow != "")
	{
	  /*alert(ctrlToHide);*/
	  if(document.getElementById(ctrlToShow))
	  document.getElementById(ctrlToShow).style.display = "";
	}
}

function mig_clay(){
if(!mig_lay()){isOK=0  
//alert("DHTML TIP MESSAGE VERSION 1.5 ERROR NOTICE.\n<DIV ID=\""+TipId+"\"></DIV> tag missing or its ID has been altered")
} 
else{mig_hand();mig_cssf()}}

function stm1(val,val2,close) {
  var msgImg = 'images/' +'Home/InfoBubble16hg.gif'
  closeImg = 'images/UI/close_icon.gif'
  var strHeading='<img src="'+ msgImg +'" /><strong class="text">&nbsp;Message<br/></strong>'
  Text[1]=[strHeading,'<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;<A href="JavaScript:showHomeMessage('+val2+')">Read More...</A>']
  if (close)
    stm(Text[1],Style[111],'hoMes')
  else
    stm(Text[1],Style[2],'hoMes')
}
function stm2(val,val2,close,strType) {

  var msgImg = 'images/' +'Task List 16 n g.gif'
  closeImg = 'images/' +'close_btn.gif'
  if(strType=='1' || strType=='3')
  {
		//style="margin-top:0;"
		Text[1]=['<img src="'+ msgImg +'" /><span valign="top"><strong class="text">&nbsp;To Do</strong></span>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;<A href="JavaScript:showHomeToDo('+val2+','+strType+')">Read More...</A>']
  }
  else if (strType=='10')
  {
		Text[1]=['<img src="'+ msgImg +'" /><span valign="top"><strong class="text">&nbsp;To Do</strong></span>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;<A href=JavaScript:showHomeToDo("'+val2+'","'+strType+'")>Read More...</A>']
  }
  else
  {
		Text[1]=['<img src="'+ msgImg +'" /><span valign="top"><strong class="text">&nbsp;To Do</strong></span>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;<A href=JavaScript:showHomeToDoCAR("'+val2+'","'+strType+'")>Read More...</A>']
  }
  //<A href="JavaScript:showHomeMessage('+val2+')">Read More...</A>'
  
  //alert ('abc :'+Text[1]);
  
  if (close)
    stm(Text[1],Style[111],'tdMes')
  else
    stm(Text[1],Style[2],'tdMes')
}
function stm3(val,close) {
  var msgImg = 'images/' +'Readeractive.gif'
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<img src="'+ msgImg +'" /><strong class="text">&nbsp;Sharing</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm4(val,close) {
  var msgImg = 'images/' +'facilityactive.gif'
  
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<img src="'+ msgImg +'" /><strong class="text">&nbsp;Facility Links</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm5(val,close) {
  
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;Claim Summary</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm6(val,close) {
  
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;Ownership</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm7(val,close) {
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;Facility Detail</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm8(tipHeading,val,close) {
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;'+tipHeading+'</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
//stm9() used for display complete report name, added on 03-04-209 by Surya
function stm9(val,close) {  
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;Report Name</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
}
function stm10(val,close) {  
  //alert ('hi');
  closeImg = 'images/' +'close_btn.gif'
  Text[1]=['<strong class="text">&nbsp;List Name</strong>','<font size="2" color="darkblue">'+val+'</font>' +'&nbsp;&nbsp;&nbsp;&nbsp;']
  stm(Text[1],Style[2],'tdMes')
  
}
// Style[001]=["white","black","#ff0033","#FFFFFF","","","","","","","","sticky","","",200,"",2,2,10,10,"","","","",""]
// Style 0 is a sticky with a close the 2 is the border size, 3 is pad and 3 is the sticky indicator
Style[0]=["black","#a5c363","","","",,"black","#dedbed","","","",,,,2,"#a5c363",3,,,,,"",3,,,]
//Style[2]=  ["black","#a5c363","","","",,"black","#dedbed","","","",,,,2,"#a5c363",2,,,,,"",3,,,]
Style[2]=  ["black","#ffffff","","","",,"black","#ffffff","","","",,,,2,"#ffffff",2,,,,,"",3,,,]
// same as style 1 but shifts the box above 40px to get around dropdowns
Style[111]=["333333","#a5c363","","","",,"333333","#dedbed","","","",,,,2,"#a5c363",2,,,,,"",1,,,]
var TipId="sstips"
var FiltersEnabled = 0 // [for IE5.5+] if your not going to use transitions or filters in any of the tips set this to zero.
var TipId="hmtips"
var FiltersEnabled = 0 // [for IE5.5+] if your not going to use transitions or filters in any of the tips set this to zero.

/************* Used for show/hide ************/
function showHideToggle()
{
    var img;
    img = document.getElementById("showhidetools");
    if (img.alt=="Show Tools")
    {
        img.alt="Hide Tools";
        img.src = "../images/ui/data_hidetools.jpg";
        document.getElementById("divShowHide").style.display="block";         
    }
    else if (img.alt=="Hide Tools")
    {
        img.alt="Show Tools";
        img.src = "../images/ui/show_tools.gif";
        document.getElementById("divShowHide").style.display="none"; 
    }
}
//-->