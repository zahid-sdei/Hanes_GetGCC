﻿function trimString(str) {
    str = this != window ? this : str;
    return str.replace(/^\s+/g, '').replace(/\s+$/g, '');
}

// Checks if defaultPathToImagesForPreloading has already been declared
if (window.defaultPathToImagesForPreloading === undefined) {
    var defaultPathToImagesForPreloading = "../";
}

//rollover function for single images
function rollImage(imagename, imageloc) {
    if (currentpage != imageloc) {
        document.images[imageloc].src = imagename.src;
    }
}

/*  Ticket         : 864
Changed By     : Ashish Sharma
Changed Reason : Java Script wrongly validating .bmp files
Changed Date   : Sep 01 2009
*/
//for checking the pdf files for uploading
function isPDF(file) {
    if (file != '') {
        if (file.lastIndexOf('.') == -1)
            return false;
        var ext = file.substr(file.lastIndexOf('.')).toLowerCase()
        return '.png,.gif,.ppt,.pptx,.docx,.xlsx,.pdf,.doc,.xls,.tif,.jpg,.jpeg,.zip,.bmp'.indexOf(ext) != -1;
    }
    else
        return true;
}
//End of Ticket 864


function GetXmlHttpObject() {
    var objXMLHttpCom = null;

    if (window.XMLHttpRequest) {
        objXMLHttpCom = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        objXMLHttpCom = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return objXMLHttpCom;
}

// Ticket 3381
// Insert text at current position
//myField accepts an object reference, myValue accepts the text strint to add
function insertAtCursor(myField, myValue) {
    if (document.selection) ///IE support
    {
        myField.focus();
        //in effect we are creating a text range with zero length at the cursor location and replacing it with myValue
        sel = document.selection.createRange();
        sel.text = myValue;
    }
    else if (myField.selectionStart || myField.selectionStart == '0') //Mozilla/Firefox/Netscape 7+ support
    {
        //Here we get the start and end points of the selection. Then we create substrings up to the start of the selection and 
        //from the end point of the selection to the end of the field value. Then we concatenate the first substring, myValue,
        //and the second substring to get the new value.
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
    }
    else {
        myField.value += myValue;
    }
}

//Added for ticket 4334
function fnKeyFocus(ev, btn) {
    if (ev.keyCode == 13) {
        document.getElementById(btn).click();
    }
}
